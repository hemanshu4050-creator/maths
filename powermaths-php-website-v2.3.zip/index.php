<?php
/**
 * Power Maths — Public Marketing Landing Page (PHP)
 * by Prof. Kalpesh Vyas
 *
 * A premium mathematics-development programme for students aged 11–18.
 * Brand: "Don't Just Learn Maths. Master the Power Behind It!"
 *
 * Single-file PHP page. The PHP layer handles only the parent-enquiry
 * form (validation + JSON persistence). Everything else is static
 * HTML/CSS/vanilla JS so the page runs on any PHP host (PHP 7.4+).
 *
 * Branding matches the official logo: circular badge with "POWER MATHS"
 * (top arc) + "KALPESH VYAS" (bottom arc), electric-blue → navy gradient,
 * gold lightning-bolt accent.
 *
 * v2.0.0 — Marketing transformation: reframed as a structured
 * mathematics-learning programme. Parent-consultation enquiry form
 * replaces self-registration.
 */

// ─────────────────────── Parent enquiry form handler ───────────────────────
$success = false;
$errors = [];
$form = [
    'parent_name'    => '',
    'email'          => '',
    'phone'          => '',
    'student_name'   => '',
    'student_age'    => '',
    'message'        => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Honeypot anti-spam — humans never fill this hidden field.
    if (!empty($_POST['website'])) {
        $errors[] = 'Spam detected.';
    } else {
        $form['parent_name']     = trim($_POST['parent_name'] ?? '');
        $form['email']           = trim($_POST['email'] ?? '');
        $form['phone']           = trim($_POST['phone'] ?? '');
        $form['student_name']    = trim($_POST['student_name'] ?? '');
        $form['student_age']     = trim($_POST['student_age'] ?? '');
        $form['message']         = trim($_POST['message'] ?? '');

        if ($form['parent_name'] === '') {
            $errors[] = 'Parent\'s name is required.';
        }
        if ($form['email'] === '' || !filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'A valid email address is required.';
        }

        if (empty($errors)) {
            $entry = [
                'submitted_at'    => date('c'),
                'parent_name'     => $form['parent_name'],
                'email'           => $form['email'],
                'phone'           => $form['phone'],
                'student_name'    => $form['student_name'],
                'student_age'     => $form['student_age'],
                'message'         => $form['message'],
                'ip'              => $_SERVER['REMOTE_ADDR'] ?? 'cli',
                'ua'              => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            ];
            $file = __DIR__ . '/submissions.json';
            $existing = file_exists($file) ? json_decode((string)file_get_contents($file), true) : [];
            if (!is_array($existing)) { $existing = []; }
            $existing[] = $entry;
            file_put_contents($file, json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);

            // v2.1.0 — Forward every enquiry to Prof. Kalpesh Vyas at
            // kvmaths@gmail.com. Uses PHP mail() — best-effort (suppressed
            // errors) so the form still succeeds even on hosts without a
            // configured mail server. The JSON log above is the fallback.
            $to      = 'kvmaths@gmail.com';
            $subject = 'Power Maths — New Parent Enquiry from ' . $entry['parent_name'];
            $body    = "New parent enquiry received on the Power Maths website.\n\n"
                     . "Parent's Name:   " . $entry['parent_name'] . "\n"
                     . "Email:           " . $entry['email'] . "\n"
                     . "Phone:           " . $entry['phone'] . "\n"
                     . "Student's Name: " . $entry['student_name'] . "\n"
                     . "Age / Standard: " . $entry['student_age'] . "\n"
                     . "Message:        " . $entry['message'] . "\n\n"
                     . "Submitted at:    " . $entry['submitted_at'] . "\n"
                     . "IP:             " . $entry['ip'] . "\n";
            $headers = "From: Power Maths Website <no-reply@powermaths.com>\r\n"
                     . "Reply-To: " . $entry['email'] . "\r\n"
                     . "Content-Type: text/plain; charset=UTF-8\r\n";
            @mail($to, $subject, $body, $headers);

            $success = true;
            $form = [
                'parent_name'    => '',
                'email'          => '',
                'phone'          => '',
                'student_name'   => '',
                'student_age'    => '',
                'message'        => '',
            ];
        }
    }
}

/** tiny helper for safe output */
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Power Maths by Prof. Kalpesh Vyas | Build Mathematical Confidence</title>
<meta name="description" content="Discover Power Maths, a structured mathematics-learning programme for students aged 11–18. Build strong concepts, logical thinking, problem-solving skills, and confidence. Contact us to discuss your child's learning path.">
<meta name="keywords" content="mathematics learning programme, maths concept building, mental maths and logical reasoning, structured maths learning, maths problem-solving skills, mathematics guidance for students aged 11–18">
<meta name="theme-color" content="#1e3a8a">
<link rel="icon" type="image/png" href="assets/logo.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:wght@700;800;900&display=swap" rel="stylesheet">
<style>
/* ─────────────────────── Design tokens ─────────────────────── */
:root {
  --navy:        #0f172a;
  --navy-2:      #1e3a8a;
  --blue:        #3b82f6;
  --blue-light:  #60a5fa;
  --blue-50:     #eff6ff;
  --gold:        #fbbf24;
  --gold-dark:   #f59e0b;
  --gold-50:     #fffbeb;
  --silver:      #e2e8f0;
  --white:       #ffffff;
  --muted:       #64748b;
  --muted-2:     #475569;
  --bg:          #f8fafc;
  --text:        #0f172a;
  --border:      #e2e8f0;
  --radius:      16px;
  --radius-sm:   10px;
  --shadow-sm:   0 1px 2px rgba(15,23,42,.06), 0 1px 3px rgba(15,23,42,.04);
  --shadow:      0 10px 30px -10px rgba(15,23,42,.15);
  --shadow-lg:   0 25px 50px -12px rgba(15,23,42,.25);
  --maxw:        1200px;
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .001ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .001ms !important;
    scroll-behavior: auto !important;
  }
}
*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  margin: 0;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  color: var(--text);
  background: var(--bg);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}
img { max-width: 100%; display: block; }
a { color: inherit; text-decoration: none; }
.container { max-width: var(--maxw); margin: 0 auto; padding: 0 24px; }

/* ─────────────────────── Header ─────────────────────── */
.site-header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(15, 23, 42, .92);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(255,255,255,.08);
  transition: box-shadow .3s ease;
}
.site-header.scrolled { box-shadow: 0 4px 20px rgba(0,0,0,.3); }
.nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 68px;
}
.brand {
  display: flex;
  align-items: center;
  gap: 12px;
}
.brand-logo {
  width: 44px; height: 44px;
  border-radius: 50%;
  box-shadow: 0 0 0 2px rgba(251,191,36,.4), 0 0 20px rgba(59,130,246,.5);
}
.brand-text { color: var(--white); line-height: 1.1; }
.brand-name {
  font-family: 'Playfair Display', serif;
  font-weight: 900;
  font-size: 1.15rem;
  letter-spacing: .5px;
  background: linear-gradient(135deg, var(--gold), #fde68a);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
.brand-sub {
  font-size: .72rem;
  color: var(--blue-light);
  letter-spacing: .5px;
  text-transform: uppercase;
  font-weight: 500;
}
.nav-links {
  display: flex;
  align-items: center;
  gap: 28px;
  list-style: none;
  margin: 0; padding: 0;
}
.nav-links a {
  color: rgba(255,255,255,.8);
  font-size: .9rem;
  font-weight: 500;
  transition: color .2s;
  position: relative;
}
.nav-links a:hover { color: var(--gold); }
.nav-links a::after {
  content: '';
  position: absolute;
  left: 0; bottom: -6px;
  width: 0; height: 2px;
  background: var(--gold);
  transition: width .25s ease;
}
.nav-links a:hover::after { width: 100%; }
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 11px 22px;
  border-radius: 999px;
  font-weight: 600;
  font-size: .9rem;
  cursor: pointer;
  border: none;
  transition: all .2s ease;
  text-decoration: none;
  white-space: nowrap;
}
.btn-gold {
  background: linear-gradient(135deg, var(--gold), var(--gold-dark));
  color: var(--navy);
  box-shadow: 0 4px 14px rgba(251,191,36,.4);
}
.btn-gold:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(251,191,36,.5); }
.btn-outline {
  background: transparent;
  color: var(--white);
  border: 1.5px solid rgba(255,255,255,.3);
}
.btn-outline:hover { border-color: var(--gold); color: var(--gold); }
.btn-blue {
  background: linear-gradient(135deg, var(--blue), var(--navy-2));
  color: var(--white);
  box-shadow: 0 4px 14px rgba(59,130,246,.4);
}
.btn-blue:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(59,130,246,.5); }
.btn-lg { padding: 14px 30px; font-size: 1rem; }

.hamburger {
  display: none;
  background: none;
  border: none;
  color: var(--white);
  cursor: pointer;
  padding: 8px;
}
.hamburger svg { width: 26px; height: 26px; }

/* ─────────────────────── Hero ─────────────────────── */
.hero {
  position: relative;
  background: radial-gradient(ellipse at top, var(--navy-2) 0%, var(--navy) 50%, #020617 100%);
  color: var(--white);
  overflow: hidden;
  padding: 90px 0 100px;
}
.hero::before {
  content: '';
  position: absolute; inset: 0;
  background-image:
    radial-gradient(circle at 20% 30%, rgba(59,130,246,.25), transparent 40%),
    radial-gradient(circle at 80% 70%, rgba(251,191,36,.15), transparent 40%);
  pointer-events: none;
}
.math-bg {
  position: absolute; inset: 0;
  opacity: .06;
  font-family: 'Playfair Display', serif;
  font-size: 120px;
  font-weight: 900;
  color: var(--white);
  pointer-events: none;
  user-select: none;
  overflow: hidden;
}
.math-bg span { position: absolute; }
.math-bg span:nth-child(1) { top: 10%; left: 8%; }
.math-bg span:nth-child(2) { top: 70%; left: 15%; font-size: 80px; }
.math-bg span:nth-child(3) { top: 30%; right: 10%; font-size: 90px; }
.math-bg span:nth-child(4) { top: 80%; right: 18%; font-size: 70px; }
.math-bg span:nth-child(5) { top: 50%; left: 45%; font-size: 60px; }

.hero-inner {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  gap: 60px;
  align-items: center;
}
.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 14px;
  border-radius: 999px;
  background: rgba(251,191,36,.12);
  border: 1px solid rgba(251,191,36,.3);
  color: var(--gold);
  font-size: .78rem;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
  margin-bottom: 24px;
}
.hero-badge .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--gold); box-shadow: 0 0 8px var(--gold); animation: pulse 2s infinite; }
@keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: .4; } }
.hero h1 {
  font-family: 'Playfair Display', serif;
  font-size: clamp(2.4rem, 5vw, 4rem);
  font-weight: 900;
  line-height: 1.1;
  margin: 0 0 20px;
  letter-spacing: -1px;
}
.hero h1 .accent {
  background: linear-gradient(135deg, var(--gold), #fde68a);
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
.hero p.lead {
  font-size: 1.08rem;
  color: rgba(255,255,255,.78);
  max-width: 560px;
  margin: 0 0 18px;
}
.hero p.lead strong { color: var(--white); font-weight: 600; }
.hero-meta {
  font-size: .88rem;
  color: var(--blue-light);
  margin: 0 0 32px;
  font-weight: 500;
}
.hero-ctas { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 36px; }
.hero-trust { display: grid; grid-template-columns: repeat(2, 1fr); gap: 14px; max-width: 520px; }
.trust-item {
  display: flex;
  align-items: center;
  gap: 10px;
  color: rgba(255,255,255,.78);
  font-size: .84rem;
  padding: 10px 14px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 10px;
}
.trust-item svg { width: 18px; height: 18px; color: var(--gold); flex-shrink: 0; }

/* Hero visual — elegant math-thinking ring (replaces floating stat cards) */
.hero-logo-wrap {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
}
.hero-logo-glow {
  position: absolute;
  width: 380px; height: 380px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(59,130,246,.35), transparent 70%);
  filter: blur(40px);
  animation: float 6s ease-in-out infinite;
}
.hero-logo {
  position: relative;
  width: 280px; height: 280px;
  border-radius: 50%;
  box-shadow: 0 0 0 8px rgba(255,255,255,.06), 0 30px 80px rgba(0,0,0,.5);
  animation: float 6s ease-in-out infinite;
  z-index: 3;
}
@keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-16px); } }

/* Concept ring — rotating math symbols around the logo */
.concept-ring {
  position: absolute;
  width: 420px; height: 420px;
  border: 1.5px dashed rgba(251,191,36,.25);
  border-radius: 50%;
  animation: rotate 40s linear infinite;
  z-index: 2;
}
.concept-ring.r2 {
  width: 500px; height: 500px;
  border-color: rgba(59,130,246,.18);
  animation: rotate 60s linear infinite reverse;
}
@keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.concept-ring .sym {
  position: absolute;
  font-family: 'Playfair Display', serif;
  font-weight: 900;
  font-size: 1.6rem;
  color: var(--gold);
  background: var(--navy);
  width: 44px; height: 44px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  border: 1px solid rgba(251,191,36,.3);
  top: 50%; left: 50%;
  margin: -22px 0 0 -22px;
  animation: counter-rotate 40s linear infinite;
}
.concept-ring.r2 .sym { animation: counter-rotate 60s linear infinite reverse; color: var(--blue-light); border-color: rgba(59,130,246,.3); font-size: 1.3rem; width: 38px; height: 38px; margin: -19px 0 0 -19px; }
@keyframes counter-rotate { from { transform: rotate(0deg); } to { transform: rotate(-360deg); } }

/* ─────────────────────── Section base ─────────────────────── */
section { padding: 80px 0; }
.section-head { text-align: center; max-width: 760px; margin: 0 auto 56px; }
.eyebrow {
  display: inline-block;
  font-size: .78rem;
  font-weight: 700;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: var(--blue);
  margin-bottom: 14px;
}
.section-head h2 {
  font-family: 'Playfair Display', serif;
  font-size: clamp(1.9rem, 3.5vw, 2.7rem);
  font-weight: 800;
  margin: 0 0 14px;
  letter-spacing: -.5px;
  color: var(--navy);
}
.section-head p { color: var(--muted); font-size: 1.05rem; margin: 0; }

/* ─────────────────────── Benefits strip (replaces stats bar) ─────────────────────── */
.benefits-strip {
  background: var(--white);
  border-bottom: 1px solid var(--border);
}
.benefits-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  padding: 36px 0;
}
.benefit-tile {
  text-align: center;
  padding: 14px 16px;
}
.benefit-tile .ico {
  width: 48px; height: 48px;
  border-radius: 12px;
  background: linear-gradient(135deg, rgba(59,130,246,.1), rgba(251,191,36,.1));
  color: var(--navy-2);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 12px;
}
.benefit-tile .ico svg { width: 22px; height: 22px; }
.benefit-tile .lbl {
  font-size: .88rem;
  font-weight: 600;
  color: var(--navy);
  line-height: 1.3;
}

/* ─────────────────────── Features ─────────────────────── */
.features { background: var(--white); }
.features-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 22px;
}
.feature-card {
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 28px 24px;
  transition: all .3s ease;
  position: relative;
  overflow: hidden;
}
.feature-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--blue), var(--gold));
  transform: scaleX(0);
  transform-origin: left;
  transition: transform .3s ease;
}
.feature-card:hover { transform: translateY(-6px); box-shadow: var(--shadow); border-color: transparent; }
.feature-card:hover::before { transform: scaleX(1); }
.feature-icon {
  width: 50px; height: 50px;
  border-radius: 13px;
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, rgba(59,130,246,.12), rgba(30,58,138,.12));
  color: var(--blue);
  margin-bottom: 16px;
}
.feature-icon svg { width: 24px; height: 24px; }
.feature-card.gold .feature-icon { background: linear-gradient(135deg, rgba(251,191,36,.15), rgba(245,158,11,.15)); color: var(--gold-dark); }
.feature-card h3 {
  font-size: 1.08rem;
  font-weight: 700;
  margin: 0 0 8px;
  color: var(--navy);
  line-height: 1.3;
}
.feature-card p { color: var(--muted); font-size: .9rem; margin: 0; line-height: 1.55; }

/* ─────────────────────── Levels ─────────────────────── */
.levels { background: linear-gradient(180deg, var(--blue-50), var(--white)); }
.levels-note {
  background: var(--gold-50);
  border: 1px solid rgba(251,191,36,.3);
  border-radius: var(--radius-sm);
  padding: 14px 20px;
  margin: 0 auto 40px;
  max-width: 720px;
  text-align: center;
  font-size: .9rem;
  color: var(--muted-2);
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
}
.levels-note svg { width: 20px; height: 20px; color: var(--gold-dark); flex-shrink: 0; }
.levels-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.level-card {
  background: var(--white);
  border-radius: var(--radius);
  padding: 32px 28px;
  border: 2px solid var(--border);
  transition: all .3s;
  position: relative;
  display: flex;
  flex-direction: column;
}
.level-card:hover { border-color: var(--blue); transform: translateY(-4px); box-shadow: var(--shadow); }
.level-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 52px; height: 52px;
  border-radius: 13px;
  background: linear-gradient(135deg, var(--navy-2), var(--blue));
  color: var(--white);
  font-family: 'Playfair Display', serif;
  font-weight: 900;
  font-size: 1.25rem;
  margin-bottom: 18px;
}
.level-card.gold .level-badge { background: linear-gradient(135deg, var(--gold-dark), var(--gold)); color: var(--navy); }
.level-card.dark .level-badge { background: linear-gradient(135deg, var(--navy), var(--navy-2)); }
.level-card .level-tag {
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: var(--blue);
  margin-bottom: 8px;
}
.level-card.gold .level-tag { color: var(--gold-dark); }
.level-card.dark .level-tag { color: var(--navy-2); }
.level-card h3 {
  font-family: 'Playfair Display', serif;
  font-size: 1.35rem;
  margin: 0 0 6px;
  color: var(--navy);
  line-height: 1.25;
}
.level-card .subhead {
  font-size: 1rem;
  font-weight: 600;
  color: var(--navy-2);
  margin: 0 0 14px;
}
.level-card .desc {
  color: var(--muted);
  font-size: .92rem;
  margin: 0 0 20px;
  line-height: 1.6;
}
.level-card ul { list-style: none; padding: 0; margin: 0 0 24px; flex-grow: 1; }
.level-card ul li {
  font-size: .88rem;
  color: var(--muted-2);
  padding: 6px 0 6px 24px;
  position: relative;
  line-height: 1.5;
}
.level-card ul li::before {
  content: '✓';
  position: absolute; left: 0; top: 6px;
  color: var(--gold-dark);
  font-weight: 800;
}
.level-card .btn { width: 100%; justify-content: center; }

/* ─────────────────────── Tagline strip ─────────────────────── */
.taglines {
  background: linear-gradient(135deg, var(--navy-2), var(--navy));
  color: var(--white);
  padding: 40px 0;
  overflow: hidden;
}
.taglines-track {
  display: flex;
  gap: 60px;
  animation: marquee 60s linear infinite;
  white-space: nowrap;
  width: max-content;
}
.taglines:hover .taglines-track { animation-play-state: paused; }
@keyframes marquee {
  from { transform: translateX(0); }
  to   { transform: translateX(-50%); }
}
.tagline-item {
  display: inline-flex;
  align-items: center;
  gap: 14px;
  font-family: 'Playfair Display', serif;
  font-size: 1.25rem;
  font-weight: 700;
  font-style: italic;
}
.tagline-item .dot { color: var(--gold); font-size: 1.4rem; }
.tagline-item .star { color: var(--gold); font-size: .8rem; }

/* ─────────────────────── Pathways (Aaj Ki Maths) ─────────────────────── */
.pathways { background: var(--white); }
.pathways .section-head .eyebrow { color: var(--gold-dark); }
.pathways-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}
.pathway-card {
  background: var(--white);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  transition: all .35s ease;
  display: flex;
  flex-direction: column;
  position: relative;
}
.pathway-card:hover {
  transform: translateY(-8px);
  box-shadow: var(--shadow-lg);
  border-color: transparent;
}
.pathway-img-wrap {
  position: relative;
  height: 180px;
  overflow: hidden;
  background: var(--navy);
}
.pathway-img-wrap img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform .5s ease;
}
.pathway-card:hover .pathway-img-wrap img { transform: scale(1.08); }
.pathway-img-wrap::after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(180deg, rgba(15,23,42,0) 40%, rgba(15,23,42,.75) 100%);
}
.pathway-badge {
  position: absolute;
  top: 14px; left: 14px;
  z-index: 2;
  background: linear-gradient(135deg, var(--gold), var(--gold-dark));
  color: var(--navy);
  font-family: 'Playfair Display', serif;
  font-weight: 900;
  font-size: 1.5rem;
  width: 54px; height: 54px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 6px 18px rgba(251,191,36,.4);
}
.pathway-name {
  position: absolute;
  bottom: 14px; left: 18px; right: 18px;
  z-index: 2;
  color: var(--white);
}
.pathway-name .abbr {
  font-family: 'Playfair Display', serif;
  font-weight: 800;
  font-size: 1.4rem;
  line-height: 1;
}
.pathway-name .full {
  font-size: .8rem;
  color: rgba(255,255,255,.85);
  margin-top: 2px;
}
.pathway-body { padding: 22px 24px 24px; flex-grow: 1; }
.pathway-body p {
  color: var(--muted);
  font-size: .9rem;
  margin: 0;
  line-height: 1.6;
}
.pathway-body .focus {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-top: 14px;
  font-size: .78rem;
  font-weight: 600;
  color: var(--blue);
  text-transform: uppercase;
  letter-spacing: .5px;
}
.pathway-body .focus svg { width: 14px; height: 14px; }

.pathways-banner {
  margin-top: 40px;
  background: linear-gradient(135deg, var(--navy), var(--navy-2));
  border-radius: var(--radius);
  padding: 36px 40px;
  color: var(--white);
  text-align: center;
  position: relative;
  overflow: hidden;
}
.pathways-banner::before {
  content: '∑';
  position: absolute;
  font-family: 'Playfair Display', serif;
  font-size: 220px;
  font-weight: 900;
  color: rgba(255,255,255,.04);
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  line-height: 1;
  pointer-events: none;
}
.pathways-banner h3 {
  font-family: 'Playfair Display', serif;
  font-size: clamp(1.4rem, 2.5vw, 2rem);
  margin: 0 0 8px;
  position: relative;
}
.pathways-banner h3 .accent { color: var(--gold); }
.pathways-banner p {
  color: rgba(255,255,255,.75);
  font-size: .95rem;
  margin: 0 0 22px;
  position: relative;
  max-width: 640px;
  margin-left: auto; margin-right: auto;
}
.pathways-banner .btn { position: relative; }

.pathways-closing {
  text-align: center;
  margin-top: 36px;
  font-family: 'Playfair Display', serif;
  font-size: clamp(1.3rem, 2.5vw, 1.8rem);
  font-weight: 700;
  color: var(--navy);
  font-style: italic;
}
.pathways-closing::before,
.pathways-closing::after {
  content: '✦';
  color: var(--gold);
  margin: 0 14px;
  font-size: 1rem;
  vertical-align: middle;
}

/* ─────────────────────── About ─────────────────────── */
.about { background: var(--navy); color: var(--white); }
.about-grid {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 60px;
  align-items: center;
}
.about-photo {
  position: relative;
  max-width: 320px;
  margin: 0 auto;
}
.about-photo img {
  width: 100%;
  border-radius: 24px;
  border: 4px solid rgba(251,191,36,.3);
  box-shadow: 0 30px 60px rgba(0,0,0,.5);
}
.about-photo .sig {
  position: absolute;
  bottom: -20px; right: -20px;
  background: var(--gold);
  color: var(--navy);
  padding: 10px 18px;
  border-radius: 12px;
  font-family: 'Playfair Display', serif;
  font-weight: 700;
  font-style: italic;
  box-shadow: var(--shadow);
}
.about h2 {
  font-family: 'Playfair Display', serif;
  font-size: clamp(1.8rem, 3vw, 2.5rem);
  margin: 0 0 8px;
  line-height: 1.2;
}
.about h2 .accent { color: var(--gold); }
.about p { color: rgba(255,255,255,.78); font-size: 1rem; margin: 0 0 16px; }
.about-creds {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 20px;
  margin-top: 28px;
  padding-top: 28px;
  border-top: 1px solid rgba(255,255,255,.1);
}
.cred .num { font-family: 'Playfair Display', serif; font-size: 1.9rem; font-weight: 900; color: var(--gold); }
.cred .lbl { font-size: .82rem; color: rgba(255,255,255,.65); line-height: 1.4; margin-top: 4px; }

/* ─────────────────────── How it works ─────────────────────── */
.how { background: var(--white); }
.steps-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 24px;
  position: relative;
}
.steps-grid::before {
  content: '';
  position: absolute;
  top: 32px; left: 12%; right: 12%;
  height: 2px;
  background: linear-gradient(90deg, var(--blue), var(--gold));
  opacity: .3;
  z-index: 0;
}
.step { text-align: center; position: relative; z-index: 1; }
.step-num {
  width: 64px; height: 64px;
  border-radius: 50%;
  background: var(--white);
  border: 2px solid var(--border);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 18px;
  font-family: 'Playfair Display', serif;
  font-size: 1.5rem;
  font-weight: 900;
  color: var(--navy-2);
  box-shadow: var(--shadow-sm);
  transition: all .3s;
}
.step:hover .step-num { background: linear-gradient(135deg, var(--blue), var(--navy-2)); color: var(--white); border-color: transparent; transform: scale(1.08); }
.step h4 { font-size: 1.05rem; margin: 0 0 8px; color: var(--navy); }
.step p { color: var(--muted); font-size: .88rem; margin: 0; line-height: 1.55; }

/* ─────────────────────── Why choose ─────────────────────── */
.why { background: linear-gradient(180deg, var(--gold-50), var(--white)); }
.why-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 40px;
  align-items: center;
}
.why-list { list-style: none; padding: 0; margin: 0; }
.why-list li {
  display: flex;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid var(--border);
}
.why-list li:last-child { border-bottom: none; }
.why-check {
  flex-shrink: 0;
  width: 36px; height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--gold), var(--gold-dark));
  display: flex; align-items: center; justify-content: center;
  color: var(--navy);
  box-shadow: 0 4px 10px rgba(251,191,36,.3);
}
.why-check svg { width: 18px; height: 18px; }
.why-list h4 { margin: 2px 0 4px; font-size: 1.02rem; color: var(--navy); }
.why-list p { margin: 0; color: var(--muted); font-size: .9rem; }
.why-visual {
  background: linear-gradient(135deg, var(--navy), var(--navy-2));
  border-radius: 24px;
  padding: 40px;
  color: var(--white);
  position: relative;
  overflow: hidden;
}
.why-visual::before {
  content: 'π';
  position: absolute;
  font-family: 'Playfair Display', serif;
  font-size: 280px;
  font-weight: 900;
  color: rgba(255,255,255,.04);
  bottom: -80px; right: -30px;
  line-height: 1;
}
.why-visual h3 { font-family: 'Playfair Display', serif; font-size: 1.6rem; margin: 0 0 14px; position: relative; }
.why-visual p { color: rgba(255,255,255,.75); font-size: .95rem; margin: 0 0 24px; position: relative; }
.why-quote {
  border-left: 3px solid var(--gold);
  padding: 8px 0 8px 18px;
  font-style: italic;
  color: rgba(255,255,255,.85);
  position: relative;
  font-size: 1rem;
  line-height: 1.6;
}

/* ─────────────────────── Parents Want ─────────────────────── */
.parents { background: var(--bg); }
.parents-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 22px;
  max-width: 880px;
  margin: 0 auto;
}
.parent-card {
  background: var(--white);
  border-radius: var(--radius);
  padding: 28px;
  border: 1px solid var(--border);
  display: flex;
  gap: 18px;
  align-items: flex-start;
  transition: all .3s;
}
.parent-card:hover { transform: translateY(-4px); box-shadow: var(--shadow); border-color: var(--blue); }
.parent-card .ico {
  flex-shrink: 0;
  width: 48px; height: 48px;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--blue), var(--navy-2));
  color: var(--white);
  display: flex; align-items: center; justify-content: center;
}
.parent-card .ico svg { width: 22px; height: 22px; }
.parent-card h4 { margin: 0 0 6px; font-size: 1.05rem; color: var(--navy); }
.parent-card p { margin: 0; color: var(--muted); font-size: .9rem; line-height: 1.55; }
.parents-disclaimer {
  text-align: center;
  margin-top: 32px;
  font-size: .82rem;
  color: var(--muted);
  font-style: italic;
}

/* ─────────────────────── Contact ─────────────────────── */
.contact { background: linear-gradient(180deg, var(--white), var(--blue-50)); }
.contact-grid {
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 50px;
  align-items: start;
}
.contact-info h2 {
  font-family: 'Playfair Display', serif;
  font-size: clamp(1.8rem, 3vw, 2.4rem);
  margin: 0 0 14px;
  color: var(--navy);
  line-height: 1.2;
}
.contact-info > p { color: var(--muted); margin: 0 0 28px; font-size: 1rem; }
.contact-item { display: flex; gap: 14px; padding: 14px 0; border-bottom: 1px solid var(--border); }
.contact-item:last-child { border-bottom: none; }
.contact-item .ico {
  width: 42px; height: 42px;
  border-radius: 11px;
  background: linear-gradient(135deg, var(--blue), var(--navy-2));
  color: var(--white);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.contact-item .ico svg { width: 20px; height: 20px; }
.contact-item .lbl { font-size: .78rem; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; }
.contact-item .val { font-weight: 600; color: var(--navy); font-size: .98rem; }

/* v2.1.0 — Direct contact block for Prof. Kalpesh Vyas */
.contact-direct {
  margin-top: 28px;
  padding: 22px 24px;
  border-radius: var(--radius);
  background: linear-gradient(135deg, var(--navy-2), var(--navy));
  color: var(--white);
  position: relative;
  overflow: hidden;
}
.contact-direct::before {
  content: '';
  position: absolute;
  top: -40px; right: -40px;
  width: 140px; height: 140px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(251,191,36,.15), transparent 70%);
}
.contact-direct .direct-label {
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 6px;
  position: relative;
}
.contact-direct .direct-name {
  font-family: 'Playfair Display', serif;
  font-size: 1.3rem;
  font-weight: 800;
  margin-bottom: 14px;
  position: relative;
}
.contact-direct .direct-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
  position: relative;
}
.contact-direct .direct-item svg { width: 18px; height: 18px; color: var(--gold); flex-shrink: 0; }
.contact-direct .direct-item .v { font-size: .95rem; font-weight: 500; }
.contact-direct .direct-item .v a { color: var(--white); transition: color .2s; }
.contact-direct .direct-item .v a:hover { color: var(--gold); }
.contact-direct-note {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid rgba(255,255,255,.12);
  font-size: .78rem;
  color: rgba(255,255,255,.6);
  position: relative;
}

.contact-form {
  background: var(--white);
  border-radius: var(--radius);
  padding: 36px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
}
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.form-group { margin-bottom: 16px; }
.form-group label {
  display: block;
  font-size: .82rem;
  font-weight: 600;
  color: var(--navy);
  margin-bottom: 6px;
}
.form-group label .req { color: #dc2626; }
.form-group input,
.form-group textarea,
.form-group select {
  width: 100%;
  padding: 12px 14px;
  border: 1.5px solid var(--border);
  border-radius: var(--radius-sm);
  font-family: inherit;
  font-size: .92rem;
  background: var(--bg);
  color: var(--text);
  transition: all .2s;
}
.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  outline: none;
  border-color: var(--blue);
  background: var(--white);
  box-shadow: 0 0 0 3px rgba(59,130,246,.12);
}
.form-group textarea { resize: vertical; min-height: 110px; }
.form-group select { cursor: pointer; appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%2364748b' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 14px center; padding-right: 38px; }
.honeypot { position: absolute; left: -9999px; top: -9999px; }

.alert {
  padding: 12px 16px;
  border-radius: var(--radius-sm);
  font-size: .9rem;
  margin-bottom: 18px;
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
.alert-success { background: #ecfdf5; border: 1px solid #6ee7b7; color: #065f46; }
.alert-error { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; }
.alert ul { margin: 0; padding-left: 20px; }

/* ─────────────────────── Footer ─────────────────────── */
.site-footer {
  background: var(--navy);
  color: rgba(255,255,255,.7);
  padding: 60px 0 28px;
}
.footer-grid {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr 1.2fr;
  gap: 40px;
  padding-bottom: 40px;
  border-bottom: 1px solid rgba(255,255,255,.1);
}
.footer-brand { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.footer-brand img { width: 48px; height: 48px; border-radius: 50%; }
.footer-brand .name {
  font-family: 'Playfair Display', serif;
  font-weight: 900;
  font-size: 1.2rem;
  color: var(--white);
}
.footer-brand .sub { font-size: .72rem; color: var(--blue-light); text-transform: uppercase; letter-spacing: .5px; }
.footer-col p { font-size: .88rem; line-height: 1.7; margin: 0; }
.footer-col h4 { color: var(--white); font-size: .95rem; margin: 0 0 16px; font-weight: 600; }
.footer-col ul { list-style: none; padding: 0; margin: 0; }
.footer-col ul li { padding: 6px 0; }
.footer-col ul li a { color: rgba(255,255,255,.7); font-size: .88rem; transition: color .2s; }
.footer-col ul li a:hover { color: var(--gold); }
.footer-bottom {
  padding-top: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  font-size: .82rem;
}
.footer-bottom .social { display: flex; gap: 10px; }
.footer-bottom .social a {
  width: 36px; height: 36px;
  border-radius: 50%;
  background: rgba(255,255,255,.08);
  display: flex; align-items: center; justify-content: center;
  transition: all .2s;
}
.footer-bottom .social a:hover { background: var(--gold); color: var(--navy); }
.footer-bottom .social svg { width: 16px; height: 16px; }

/* ─────────────────────── Back to top ─────────────────────── */
.back-top {
  position: fixed;
  bottom: 24px; right: 24px;
  width: 48px; height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--blue), var(--navy-2));
  color: var(--white);
  border: none;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  box-shadow: var(--shadow-lg);
  opacity: 0;
  visibility: hidden;
  transform: translateY(10px);
  transition: all .3s;
  z-index: 90;
}
.back-top.show { opacity: 1; visibility: visible; transform: translateY(0); }
.back-top:hover { transform: translateY(-3px); }
.back-top svg { width: 22px; height: 22px; }

/* ─────────────────────── Scroll animations ─────────────────────── */
.reveal {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity .7s ease, transform .7s ease;
}
.reveal.in { opacity: 1; transform: translateY(0); }

/* ─────────────────────── Responsive ─────────────────────── */
@media (max-width: 980px) {
  .hero-inner { grid-template-columns: 1fr; gap: 40px; text-align: center; }
  .hero-ctas, .hero-trust { justify-content: center; }
  .hero-trust { margin: 0 auto; }
  .hero p.lead { margin-left: auto; margin-right: auto; }
  .hero-logo { width: 220px; height: 220px; }
  .hero-logo-glow { width: 300px; height: 300px; }
  .concept-ring { width: 340px; height: 340px; }
  .concept-ring.r2 { width: 400px; height: 400px; }
  .features-grid { grid-template-columns: repeat(2, 1fr); }
  .levels-grid { grid-template-columns: 1fr; max-width: 480px; margin: 0 auto; }
  .pathways-grid { grid-template-columns: repeat(2, 1fr); }  /* v2.1.0 — 2-col on tablet/mobile */
  .steps-grid { grid-template-columns: repeat(2, 1fr); }
  .steps-grid::before { display: none; }
  .about-grid, .why-grid, .contact-grid { grid-template-columns: 1fr; }
  .about-creds { grid-template-columns: repeat(2, 1fr); }
  .parents-grid { grid-template-columns: 1fr; }
  .footer-grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 700px) {
  .nav-links { display: none; }
  .nav-links.open {
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 68px; left: 0; right: 0;
    background: var(--navy);
    padding: 20px 24px;
    gap: 14px;
    border-bottom: 1px solid rgba(255,255,255,.1);
  }
  .hamburger { display: block; }
  .benefits-grid { grid-template-columns: repeat(2, 1fr); gap: 14px; }
  .features-grid, .steps-grid { grid-template-columns: 1fr; }
  .pathways-grid { grid-template-columns: repeat(2, 1fr); }  /* v2.1.0 — user spec: 2 cols on mobile */
  .pathway-img-wrap { height: 140px; }  /* shorter images on small screens */
  .form-row { grid-template-columns: 1fr; }
  .footer-grid { grid-template-columns: 1fr; gap: 28px; }
  section { padding: 60px 0; }
  .hero { padding: 60px 0 70px; }
  .concept-ring { display: none; }
  .about-photo { max-width: 240px; }
  .contact-form { padding: 24px; }
}
</style>
</head>
<body>

<!-- ─────────────────────── Header ─────────────────────── -->
<header class="site-header" id="header">
  <div class="container nav">
    <a href="#home" class="brand">
      <img src="assets/logo.png" alt="Power Maths logo" class="brand-logo">
      <div class="brand-text">
        <div class="brand-name">POWER MATHS</div>
        <div class="brand-sub">by Prof. Kalpesh Vyas</div>
      </div>
    </a>
    <ul class="nav-links" id="navLinks">
      <li><a href="#home">Home</a></li>
      <li><a href="#approach">Learning Approach</a></li>
      <li><a href="#pathways">Future Pathways</a></li>
      <li><a href="#about">About</a></li>
      <li><a href="#contact">Contact</a></li>
      <li><a href="#contact" class="btn btn-gold">Discuss Your Child's Learning Plan</a></li>
    </ul>
    <button class="hamburger" id="hamburger" aria-label="Toggle menu">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>
  </div>
</header>

<!-- ─────────────────────── Hero ─────────────────────── -->
<section class="hero" id="home">
  <div class="math-bg" aria-hidden="true">
    <span>π</span><span>∑</span><span>√</span><span>∫</span><span>∞</span>
  </div>
  <div class="container hero-inner">
    <div class="hero-copy">
      <span class="hero-badge"><span class="dot"></span> Power Maths | Structured Mathematics Learning</span>
      <h1>Don't Just Learn Maths.<br><span class="accent">Master the Power Behind It!</span></h1>
      <p class="lead">Help your child move beyond memorising formulas and fearing difficult sums. Power Maths focuses on <strong>strong mathematical foundations</strong>, <strong>conceptual clarity</strong>, <strong>logical thinking</strong>, smarter problem-solving, and confidence through structured learning and guided practice.</p>
      <p class="hero-meta">Designed for students aged 11–18 · Led by Prof. Kalpesh Vyas</p>
      <div class="hero-ctas">
        <a href="#contact" class="btn btn-gold btn-lg">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
          Discuss Your Child's Learning Plan
        </a>
        <a href="#approach" class="btn btn-outline btn-lg">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
          Explore Our Learning Approach
        </a>
      </div>
      <div class="hero-trust">
        <div class="trust-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
          Concept-First Learning
        </div>
        <div class="trust-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
          Structured Learning Path
        </div>
        <div class="trust-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
          Guided Practice & Assessment
        </div>
        <div class="trust-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
          Parent-Focused Communication
        </div>
      </div>
    </div>
    <div class="hero-logo-wrap">
      <div class="hero-logo-glow"></div>
      <div class="concept-ring" aria-hidden="true">
        <span class="sym" style="transform:translate(0,-210px)">π</span>
        <span class="sym" style="transform:translate(149px,-149px)">∑</span>
        <span class="sym" style="transform:translate(210px,0)">√</span>
        <span class="sym" style="transform:translate(149px,149px)">∫</span>
        <span class="sym" style="transform:translate(0,210px)">∞</span>
        <span class="sym" style="transform:translate(-149px,149px)">θ</span>
        <span class="sym" style="transform:translate(-210px,0)">Δ</span>
        <span class="sym" style="transform:translate(-149px,-149px)">Σ</span>
      </div>
      <div class="concept-ring r2" aria-hidden="true">
        <span class="sym" style="transform:translate(0,-250px)">+</span>
        <span class="sym" style="transform:translate(177px,-177px)">×</span>
        <span class="sym" style="transform:translate(250px,0)">÷</span>
        <span class="sym" style="transform:translate(177px,177px)">=</span>
        <span class="sym" style="transform:translate(0,250px)">≠</span>
        <span class="sym" style="transform:translate(-177px,177px)">≈</span>
        <span class="sym" style="transform:translate(-250px,0)">±</span>
        <span class="sym" style="transform:translate(-177px,-177px)">∞</span>
      </div>
      <img src="assets/logo.png" alt="Power Maths official badge — by Prof. Kalpesh Vyas" class="hero-logo">
    </div>
  </div>
</section>

<!-- ─────────────────────── Benefits strip (replaces stats bar) ─────────────────────── -->
<section class="benefits-strip" style="padding:0;">
  <div class="container">
    <div class="benefits-grid">
      <div class="benefit-tile reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg></div>
        <div class="lbl">Strong Conceptual Foundations</div>
      </div>
      <div class="benefit-tile reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg></div>
        <div class="lbl">Logical and Analytical Thinking</div>
      </div>
      <div class="benefit-tile reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div>
        <div class="lbl">Smart Problem-Solving Skills</div>
      </div>
      <div class="benefit-tile reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg></div>
        <div class="lbl">Confidence Through Practice</div>
      </div>
    </div>
  </div>
</section>

<!-- ─────────────────────── Tagline strip (marketing slogans) ─────────────────────── -->
<section class="taglines" aria-label="Power Maths slogans">
  <div class="taglines-track">
    <span class="tagline-item"><span class="dot">◆</span> Maths tuition nahi. Makes you ready for future competition.</span>
    <span class="tagline-item"><span class="star">★</span> Daro nahi, karo maths!</span>
    <span class="tagline-item"><span class="dot">◆</span> Remove the Fear. Build the foundation, master the future.</span>
    <span class="tagline-item"><span class="star">★</span> From "Oh No!" to "Oh Yes!" — Think better, solve faster.</span>
    <span class="tagline-item"><span class="dot">◆</span> Socho Tez, Solve Smart — Confident bachche, tension-free parents.</span>
    <span class="tagline-item"><span class="star">★</span> Ratna nahi, samajhna hai seekho.</span>
    <span class="tagline-item"><span class="dot">◆</span> Practice. Power. Progress — Let's make maths our superpower.</span>
    <span class="tagline-item"><span class="star">★</span> No shortcuts, just smart learning.</span>
    <!-- duplicate set for seamless marquee loop -->
    <span class="tagline-item"><span class="dot">◆</span> Maths tuition nahi. Makes you ready for future competition.</span>
    <span class="tagline-item"><span class="star">★</span> Daro nahi, karo maths!</span>
    <span class="tagline-item"><span class="dot">◆</span> Remove the Fear. Build the foundation, master the future.</span>
    <span class="tagline-item"><span class="star">★</span> From "Oh No!" to "Oh Yes!" — Think better, solve faster.</span>
    <span class="tagline-item"><span class="dot">◆</span> Socho Tez, Solve Smart — Confident bachche, tension-free parents.</span>
    <span class="tagline-item"><span class="star">★</span> Ratna nahi, samajhna hai seekho.</span>
    <span class="tagline-item"><span class="dot">◆</span> Practice. Power. Progress — Let's make maths our superpower.</span>
    <span class="tagline-item"><span class="star">★</span> No shortcuts, just smart learning.</span>
  </div>
</section>

<!-- ─────────────────────── Features (Learning Approach) ─────────────────────── -->
<section class="features" id="approach">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">The Power Maths Approach</span>
      <h2>More Than Maths Tuition. A Smarter Way to Learn.</h2>
      <p>Every student deserves to understand <em>why</em> a method works, not simply memorise <em>how</em> to use it. Power Maths brings structure, practice, reasoning, and guided assessment together to help students develop stronger mathematical thinking.</p>
    </div>
    <div class="features-grid">
      <div class="feature-card reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
        </div>
        <h3>Concept-First Learning</h3>
        <p>Understand the logic behind mathematical concepts instead of relying only on memorised formulas and shortcuts.</p>
      </div>
      <div class="feature-card gold reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
        </div>
        <h3>Smart Problem-Solving</h3>
        <p>Develop a systematic approach to solving problems accurately, selecting suitable methods, and improving efficiency through practice.</p>
      </div>
      <div class="feature-card reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
        </div>
        <h3>Mental Maths & Logical Thinking</h3>
        <p>Strengthen numerical confidence, reasoning ability, pattern recognition, and mental calculation skills.</p>
      </div>
      <div class="feature-card gold reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        </div>
        <h3>Exam-Style Practice</h3>
        <p>Practise questions designed to reflect relevant school examination formats and appropriate competitive-exam patterns.</p>
      </div>
      <div class="feature-card reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
        </div>
        <h3>Guided Assessments & Feedback</h3>
        <p>Use available assessments and practice activities to identify learning gaps, review mistakes, and strengthen understanding.</p>
      </div>
      <div class="feature-card gold reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
        </div>
        <h3>Structured Learning Progression</h3>
        <p>Follow a planned learning path that develops foundational understanding before moving towards more challenging mathematical thinking.</p>
      </div>
      <div class="feature-card reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        </div>
        <h3>Parent Communication & Progress Visibility</h3>
        <p>Help parents understand their child's learning progress through the progress information and communication actually available in the programme.</p>
      </div>
      <div class="feature-card gold reveal">
        <div class="feature-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
        </div>
        <h3>Flexible Learning Resources</h3>
        <p>Present available learning materials and practice resources clearly. Accessible conveniently through the programme.</p>
      </div>
    </div>
  </div>
</section>

<!-- ─────────────────────── Pathways: Aaj Ki Maths, Kal Ke Bade Sapne! ─────────────────────── -->
<section class="pathways" id="pathways">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Future Pathways</span>
      <h2>Aaj Ki Maths, Kal Ke Bade Sapne!</h2>
      <p>Build Strong Foundations Today. Prepare for Bigger Opportunities Tomorrow.</p>
      <p style="margin-top:14px;">The right mathematical foundation can open doors to a wide range of future academic and professional pathways. Power Maths helps students build conceptual clarity, logical thinking, numerical confidence, and systematic problem-solving skills.</p>
    </div>

    <div class="pathways-grid">
      <!-- CA -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">CA</div>
          <img src="assets/pathways/ca.jpg" alt="Student preparing for Chartered Accountancy" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">CA</div>
            <div class="full">Chartered Accountancy</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>Strong quantitative aptitude, numerical accuracy, and logical reasoning form the backbone of chartered accountancy — from financial analysis to audit problem-solving.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg> Quantitative Aptitude</span>
        </div>
      </div>

      <!-- CMA -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">CMA</div>
          <img src="assets/pathways/cma.jpg" alt="Student preparing for Cost & Management Accounting" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">CMA</div>
            <div class="full">Cost & Management Accounting</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>Cost analysis, financial modelling, and systematic problem-solving rely on a clear grasp of numbers, percentages, and logical flow — all built through strong maths foundations.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg> Analytical Reasoning</span>
        </div>
      </div>

      <!-- JEE -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">JEE</div>
          <img src="assets/pathways/jee.jpg" alt="Student preparing for JEE Engineering Entrance" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">JEE</div>
            <div class="full">Engineering Entrance</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>Engineering entrances demand speed, accuracy, and deep conceptual clarity in algebra, calculus, and coordinate geometry — exactly the structured thinking Power Maths develops early.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg> Speed & Accuracy</span>
        </div>
      </div>

      <!-- MBA -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">MBA</div>
          <img src="assets/pathways/mba.jpg" alt="Student preparing for MBA Management Studies" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">MBA</div>
            <div class="full">Management Studies</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>MBA entrances test data interpretation, quantitative ability, and logical reasoning — skills that grow naturally when a student learns to think mathematically from an early age.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg> Data Interpretation</span>
        </div>
      </div>

      <!-- CET -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">CET</div>
          <img src="assets/pathways/cet.jpg" alt="Student preparing for Common Entrance Tests" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">CET</div>
            <div class="full">Common Entrance Tests</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>State and common entrance exams reward fast, pattern-based thinking and confident MCQ problem-solving — habits built through structured, timed practice.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg> MCQ Strategy</span>
        </div>
      </div>

      <!-- BBA -->
      <div class="pathway-card reveal">
        <div class="pathway-img-wrap">
          <div class="pathway-badge">BBA</div>
          <img src="assets/pathways/bba.jpg" alt="Student preparing for BBA Business Administration" loading="lazy">
          <div class="pathway-name">
            <div class="abbr">BBA</div>
            <div class="full">Business Administration</div>
          </div>
        </div>
        <div class="pathway-body">
          <p>Business administration combines quantitative analysis with decision-making — comfort with numbers, statistics, and logical reasoning gives students a clear head start.</p>
          <span class="focus"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 8v8m-4-5v5m-4-2v2M3 21h18M3 10h18M5 6h14a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2z"/></svg> Business Analytics</span>
        </div>
      </div>
    </div>

    <!-- 7th full-width message -->
    <div class="pathways-banner reveal">
      <h3>Koi Bhi Entrance Exam Ho — <span class="accent">Strong Maths Foundation Is Your Advantage!</span></h3>
      <p>Power Maths is not a substitute for dedicated CA, CMA, JEE, MBA, CET, or BBA exam coaching. It builds the conceptual clarity, logical thinking, and problem-solving habits that support every future academic pathway.</p>
      <a href="#contact" class="btn btn-gold btn-lg">Discuss Your Child's Learning Plan</a>
    </div>

    <!-- Closing message -->
    <div class="pathways-closing reveal">Your Child's Future Starts with Today's Foundation.</div>
  </div>
</section>

<!-- ─────────────────────── About ─────────────────────── -->
<section class="about" id="about">
  <div class="container about-grid">
    <div class="about-photo reveal">
      <img src="assets/logo.png" alt="Power Maths — Prof. Kalpesh Vyas">
      <div class="sig">— Prof. K. Vyas</div>
    </div>
    <div class="about-copy reveal">
      <span class="eyebrow" style="color:var(--gold);">About the Founder</span>
      <h2>Meet <span class="accent">Prof. Kalpesh Vyas</span> — Building Mathematical Confidence Through Understanding</h2>
      <p>Prof. Kalpesh Vyas believes that mathematics should be understood, not feared. His teaching philosophy focuses on building strong foundations, explaining concepts clearly, encouraging logical thinking, and helping students approach problems with confidence.</p>
      <p>Power Maths is built around a simple principle: when students understand the reasoning behind mathematics and practise systematically, they can develop stronger problem-solving habits and a healthier relationship with the subject.</p>
      <p>The goal is not merely to finish a syllabus. It is to help students think more clearly, learn more confidently, and prepare for the mathematical challenges ahead.</p>
      <div class="about-creds">
        <div class="cred">
          <div class="num">20+</div>
          <div class="lbl">Years Teaching Experience</div>
        </div>
        <div class="cred">
          <div class="num">11–18</div>
          <div class="lbl">Student Age Group Served</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ─────────────────────── How it works ─────────────────────── -->
<section class="how">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">How It Works</span>
      <h2>A Clear, Guided Path to Better Mathematics</h2>
      <p>Every student needs the right starting point, a structured learning plan, and consistent opportunities to practise. Power Maths keeps the process simple for parents and students.</p>
    </div>
    <div class="steps-grid">
      <div class="step reveal">
        <div class="step-num">1</div>
        <h4>Contact Us</h4>
        <p>Parents share their child's age, current learning stage, challenges, and academic goals through the enquiry form.</p>
      </div>
      <div class="step reveal">
        <div class="step-num">2</div>
        <h4>Discuss the Right Learning Level</h4>
        <p>Speak with the teacher to understand the student's needs and identify an appropriate starting level.</p>
      </div>
      <div class="step reveal">
        <div class="step-num">3</div>
        <h4>Follow a Structured Learning Plan</h4>
        <p>The student works through the learning materials, concept explanations, and practice activities provided through the programme.</p>
      </div>
      <div class="step reveal">
        <div class="step-num">4</div>
        <h4>Practise, Assess & Improve</h4>
        <p>Use available assessments, review mistakes, strengthen weaker areas, and work towards greater confidence and accuracy.</p>
      </div>
    </div>
  </div>
</section>

<!-- ─────────────────────── Why choose ─────────────────────── -->
<section class="why">
  <div class="container why-grid">
    <div class="why-list reveal">
      <ul>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Personal Guidance from Prof. Kalpesh Vyas</h4>
            <p>A teaching approach focused on understanding, structured practice, and the student's learning needs.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Exam-Style Questions and Problem-Solving</h4>
            <p>Develop familiarity with relevant school assessments and suitable competitive-exam question patterns.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Clear Learning Progression</h4>
            <p>Move from foundational understanding towards more challenging concepts through a structured learning journey.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Parent Communication</h4>
            <p>Help parents stay informed about their child's learning journey through the communication and progress information actually provided.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Practice That Builds Understanding</h4>
            <p>Encourage students to learn from mistakes, revisit difficult concepts, and improve through purposeful practice.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Flexible Learning Resources</h4>
            <p>Make the available learning resources convenient to access and use.</p>
          </div>
        </li>
        <li>
          <div class="why-check"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg></div>
          <div>
            <h4>Confidence Without Unnecessary Pressure</h4>
            <p>Create a learning environment where students can ask questions, strengthen their understanding, and gradually approach maths with greater confidence.</p>
          </div>
        </li>
      </ul>
    </div>
    <div class="why-visual reveal">
      <h3>The Power Maths Difference</h3>
      <p>We don't just teach maths. We help students build the confidence, reasoning, and problem-solving habits that support lifelong learning.</p>
      <blockquote class="why-quote">
        "We don't just teach maths. We help students build the confidence, reasoning, and problem-solving habits that support lifelong learning."
      </blockquote>
    </div>
  </div>
</section>

<!-- ─────────────────────── What Parents Want ─────────────────────── -->
<section class="parents">
  <div class="container">
    <div class="section-head reveal">
      <span class="eyebrow">Programme Goals</span>
      <h2>What Parents Want for Their Children</h2>
      <p>These are the priorities Power Maths is designed to support — programme goals shared by parents who want their children to develop a healthier, stronger relationship with mathematics.</p>
    </div>
    <div class="parents-grid">
      <div class="parent-card reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg></div>
        <div>
          <h4>A Stronger Understanding of Concepts</h4>
          <p>Parents want their children to genuinely understand mathematical ideas — not just memorise procedures for exams.</p>
        </div>
      </div>
      <div class="parent-card reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg></div>
        <div>
          <h4>Greater Confidence with Difficult Problems</h4>
          <p>Parents want their children to approach challenging sums without fear — building confidence through guided practice.</p>
        </div>
      </div>
      <div class="parent-card reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg></div>
        <div>
          <h4>A Structured Approach to Learning & Practice</h4>
          <p>Parents value a clear learning path — knowing their child is progressing systematically, not jumping randomly between topics.</p>
        </div>
      </div>
      <div class="parent-card reveal">
        <div class="ico"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg></div>
        <div>
          <h4>Clearer Communication About Progress</h4>
          <p>Parents want to stay informed — not just about marks, but about how their child is thinking, learning, and growing.</p>
        </div>
      </div>
    </div>
    <p class="parents-disclaimer">These reflect common parent priorities and programme goals — not individual customer testimonials.</p>
  </div>
</section>

<!-- ─────────────────────── Contact ─────────────────────── -->
<section class="contact" id="contact">
  <div class="container contact-grid">
    <div class="contact-info reveal">
      <span class="eyebrow">Get In Touch</span>
      <h2>Let's Find the Right Learning Path for Your Child</h2>
      <p>Every child has different strengths, challenges, and learning needs. Contact Power Maths to discuss your child's current level, learning goals, and the most suitable programme.</p>

      <!-- Prof. Kalpesh Vyas — direct contact -->
      <div class="contact-direct">
        <div class="direct-label">Direct Contact</div>
        <div class="direct-name">Prof. Kalpesh Vyas</div>
        <div class="direct-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
          <div class="v"><a href="tel:+919820033404">+91 98200 33404</a></div>
        </div>
        <div class="direct-item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
          <div class="v"><a href="mailto:kvmaths@gmail.com">kvmaths@gmail.com</a></div>
        </div>
        <div class="contact-direct-note">All enquiries from this page are forwarded directly to Prof. Kalpesh at kvmaths@gmail.com.</div>
      </div>
    </div>

    <div class="contact-form reveal">
      <h3 style="margin:0 0 6px; font-family:'Playfair Display',serif; font-size:1.4rem; color:var(--navy);">Request a Parent Consultation</h3>
      <p style="margin:0 0 22px; color:var(--muted); font-size:.92rem;">Fill in the form and Prof. Kalpesh's team will reach out using the contact details you provide.</p>

      <?php if ($success): ?>
        <div class="alert alert-success">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
          <div>
            <strong>Thank you — your enquiry has been received.</strong> Prof. Kalpesh's team will follow up using the contact details you provided.
          </div>
        </div>
      <?php endif; ?>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          <div>
            <strong>Please fix the following:</strong>
            <ul><?php foreach ($errors as $e) echo '<li>' . h($e) . '</li>'; ?></ul>
          </div>
        </div>
      <?php endif; ?>

      <form method="POST" action="#contact" novalidate>
        <!-- Honeypot anti-spam (hidden from humans) -->
        <div class="honeypot" aria-hidden="true">
          <label>Website (leave empty): <input type="text" name="website" tabindex="-1" autocomplete="off"></label>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="parent_name">Parent's Name <span class="req">*</span></label>
            <input type="text" id="parent_name" name="parent_name" value="<?= h($form['parent_name']) ?>" placeholder="e.g. Parent's full name" required>
          </div>
          <div class="form-group">
            <label for="email">Email Address <span class="req">*</span></label>
            <input type="email" id="email" name="email" value="<?= h($form['email']) ?>" placeholder="you@example.com" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" name="phone" value="<?= h($form['phone']) ?>" placeholder="+91 98xxx xxxxx">
          </div>
          <div class="form-group">
            <label for="student_name">Student's Name</label>
            <input type="text" id="student_name" name="student_name" value="<?= h($form['student_name']) ?>" placeholder="Your child's name (optional)">
          </div>
        </div>
        <div class="form-group">
          <label for="student_age">Student's Age / School Standard</label>
          <input type="text" id="student_age" name="student_age" value="<?= h($form['student_age']) ?>" placeholder="e.g. 14 years / Class 9">
        </div>
        <div class="form-group">
          <label for="message">Message <span class="req">*</span></label>
          <textarea id="message" name="message" placeholder="Tell us about your child's current challenges, learning goals, and what you hope to achieve through Power Maths…" required><?= h($form['message']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-blue btn-lg" style="width:100%; justify-content:center;">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>
          Request a Parent Consultation
        </button>
        <p style="margin:14px 0 0; font-size:.78rem; color:var(--muted); text-align:center;">
          🔒 Your details are safe with us. This is an enquiry form — not a registration form.
        </p>
      </form>
    </div>
  </div>
</section>

<!-- ─────────────────────── Footer ─────────────────────── -->
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-col">
        <div class="footer-brand">
          <img src="assets/logo.png" alt="Power Maths">
          <div>
            <div class="name">POWER MATHS</div>
            <div class="sub">by Prof. Kalpesh Vyas</div>
          </div>
        </div>
        <p>Power Maths by Prof. Kalpesh Vyas helps students aged 11–18 build stronger mathematical foundations, logical reasoning, problem-solving skills, and confidence through structured learning and guided practice.</p>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#approach">Learning Approach</a></li>
          <li><a href="#pathways">Future Pathways</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Future Pathways</h4>
        <ul>
          <li><a href="#pathways">CA — Chartered Accountancy</a></li>
          <li><a href="#pathways">CMA — Cost & Management</a></li>
          <li><a href="#pathways">JEE — Engineering</a></li>
          <li><a href="#pathways">MBA — Management</a></li>
          <li><a href="#pathways">CET — Entrance Tests</a></li>
          <li><a href="#pathways">BBA — Administration</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact</h4>
        <ul>
          <li style="color:var(--gold); font-size:.72rem; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:6px;">Prof. Kalpesh Vyas</li>
          <li>📧 kvmaths@gmail.com</li>
          <li>📞 +91 98200 33404</li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <div>© <?= date('Y') ?> Power Maths by Prof. Kalpesh Vyas. All rights reserved.</div>
      <div class="social">
        <a href="#" aria-label="Facebook"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"/></svg></a>
        <a href="#" aria-label="Instagram"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg></a>
        <a href="#" aria-label="YouTube"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a>
        <a href="#" aria-label="WhatsApp"><svg fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163a11.867 11.867 0 01-1.587-5.946C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 018.413 3.488 11.824 11.824 0 013.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 01-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 001.515 5.26l-.999 3.648 3.473-.607zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg></a>
      </div>
    </div>
  </div>
</footer>

<button class="back-top" id="backTop" aria-label="Back to top">
  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 15l7-7 7 7"/></svg>
</button>

<script>
// ─────────────────────── Mobile nav toggle ───────────────────────
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
hamburger?.addEventListener('click', () => navLinks.classList.toggle('open'));
navLinks?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));

// ─────────────────────── Sticky header shadow on scroll ───────────────────────
const header = document.getElementById('header');
const backTop = document.getElementById('backTop');
window.addEventListener('scroll', () => {
  const y = window.scrollY;
  header?.classList.toggle('scrolled', y > 20);
  backTop?.classList.toggle('show', y > 400);
}, { passive: true });

// ─────────────────────── Back to top ───────────────────────
backTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

// ─────────────────────── Scroll reveal (Intersection Observer) ───────────────────────
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('in');
      io.unobserve(e.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// ─────────────────────── Smooth anchor scroll offset for sticky header ───────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', (e) => {
    const id = a.getAttribute('href');
    if (id && id.length > 1) {
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        const top = target.getBoundingClientRect().top + window.scrollY - 60;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    }
  });
});
</script>
</body>
</html>
