# Power Maths — Public Website (PHP) v2.1.0

A premium, world-class PHP landing page for the Power Maths structured mathematics-learning programme by Prof. Kalpesh Vyas.

## Brand Positioning
**Slogan:** Don't Just Learn Maths. Master the Power Behind It!
**Audience:** Students aged 11–18 and their parents
**Goal:** Generate parent enquiries (not self-enrollment)

## Files
- `index.php` — The complete PHP landing page (HTML + CSS + JS + PHP enquiry form handler)
- `assets/logo.png` — Official Power Maths circular badge logo
- `assets/pathways/` — 6 pathway card images (CA, CMA, JEE, MBA, CET, BBA)
- `preview.html` — Static HTML preview (PHP tags stripped) for viewing without a PHP server
- `submissions.json` — Auto-created when the first enquiry is submitted (JSON log)

## Sections (14)
1. Sticky header (logo + nav + "Discuss Your Child's Learning Plan" CTA)
2. Hero — "Don't Just Learn Maths. Master the Power Behind It!"
3. Benefits strip — 4 benefit statements
4. **Tagline strip** (v2.1) — marquee of 8 marketing slogans (Hindi-English)
5. Learning Approach — 8 feature cards
6. **Aaj Ki Maths, Kal Ke Bade Sapne!** (v2.1) — 6 pathway cards (CA/CMA/JEE/MBA/CET/BBA) + full-width banner + closing message
7. Levels — 3 cards (Foundation / Concept Mastery / Advanced Thinking)
8. About Prof. Kalpesh Vyas — 20+ years teaching
9. How It Works — 4 teacher-guided steps
10. Why Choose — 7 benefit items + brand statement
11. What Parents Want for Their Children — 4 programme-goal cards
12. Contact — enquiry form + general contact + **Prof. Kalpesh direct** (v2.1: kvmaths@gmail.com / +91 98200 33404)
13. Footer — brand + quick links + levels + contact (incl. direct)
14. Back-to-top button

## v2.1.0 Changes
- **NEW: "Aaj Ki Maths, Kal Ke Bade Sapne!" pathways section** — 6 image cards (CA, CMA, JEE, MBA, CET, BBA) + full-width banner "Koi Bhi Entrance Exam Ho — Strong Maths Foundation Is Your Advantage!" + closing "Your Child's Future Starts with Today's Foundation."
- **NEW: Tagline marquee strip** — 8 rotating marketing slogans
- **NEW: Form-to-email forwarding** — every enquiry is emailed to kvmaths@gmail.com (via PHP mail(), best-effort, with JSON fallback)
- **UPDATED: Contact section** — added Prof. Kalpesh Vyas direct contact block (navy gradient card with phone +91 98200 33404 + email kvmaths@gmail.com)
- **UPDATED: Footer** — added Prof. Kalpesh direct contact info
- **REMOVED: Teacher-guided note** from levels section
- 6 pathway images: 5 from user's GitHub repo + 1 AI-generated (BBA)

## PHP Enquiry Form
- Fields: Parent's Name*, Email*, Phone, Student's Name, Student Age/Standard, Preferred Learning Level (with "Not Sure"), Learning Goal*, Message
- Validation + honeypot anti-spam + htmlspecialchars XSS protection
- Saves to submissions.json AND emails kvmaths@gmail.com
- "Discuss Level N" buttons auto-preselect the preferred level dropdown

## How to run
```bash
cd php-website
php -S localhost:8000
```

## Requirements
- PHP 7.4+ (PHP 8.x recommended)
- No database — JSON file persistence
- PHP mail() function (for email forwarding; falls back to JSON if unavailable)

© 2026 Power Maths by Prof. Kalpesh Vyas. · v2.1.0
